#!/usr/bin/perl

print time, "\n";
