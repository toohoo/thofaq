#!/usr/bin/perl

$leer = "";
$unde = undef;

if (!$leer) { 
	print "!leer"; 
} else {
	print "leer"; 
}
print "\n";

if (!$unde) { 
	print "!unde"; 
} else {
	print "unde"; 
}
print "\n";
