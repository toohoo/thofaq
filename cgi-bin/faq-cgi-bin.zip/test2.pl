#!D:/xampp/perl/bin/perl
#!/usr/bin/perl
print time, "\n";
